import React from 'react';

const Home = () => {
  return <h1>ברוכים הבאים pichoose</h1>;
};

export default Home;